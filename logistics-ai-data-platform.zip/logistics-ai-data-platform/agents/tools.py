"""
Tool registry — the boundary between reasoning (LLM) and execution (deterministic code).

The SAME functions are used by:
  * the in-process agent (Anthropic tool-use loop or offline planner)
  * the MCP server (mcp_server/server.py), so any MCP client can call them.
Each tool returns JSON-serialisable data, never prose.
"""
from __future__ import annotations
import json
import re
import duckdb
from platform_core import metadata as md, lineage, rca
from platform_core.config import WAREHOUSE
from platform_core.dq_engine import DQEngine
from platform_core.kpi_engine import KPIEngine
from platform_core.rag import index


def _con():
    return duckdb.connect(str(WAREHOUSE), read_only=True)


def search_knowledge(query: str, doc_type: str | None = None, k: int = 5) -> list[dict]:
    """Semantic search over data contracts, KPI definitions, DQ rules and docs."""
    return index().search(query, k=k, doc_type=doc_type)


def list_kpis() -> list[dict]:
    return [{"kpi": k, "module": v["module"], "description": v["description"]} for k, v in md.load()["kpis"].items()]


def get_kpi_definition(kpi: str) -> dict:
    return {"kpi": kpi, **md.kpi(kpi), "lineage": lineage.render(lineage.upstream(kpi))}


def get_schema(entity: str) -> dict:
    return md.entity(entity)


def calculate_kpi(kpi: str, start_date: str | None = None, end_date: str | None = None,
                  group_by: str | None = None, vendor_code: str | None = None) -> list[dict]:
    df = KPIEngine(_con()).calculate(kpi, start_date, end_date, group_by, vendor_code)
    return json.loads(df.to_json(orient="records", date_format="iso"))


def explain_kpi_change(kpi: str, window_days: int = 28, by: str = "vendor_code") -> dict:
    """Recent window vs previous window, with per-segment contribution to the change."""
    return json.loads(json.dumps(KPIEngine(_con()).compare_periods(kpi, window_days, by), default=str))


def assess_kpi_reliability(kpi: str) -> dict:
    return KPIEngine(_con()).assess_impact(kpi)


def run_dq_checks(entity: str | None = None, only_failures: bool = True) -> dict:
    eng = DQEngine(_con())
    df = eng.run_all(persist=False)
    scores = DQEngine.scores(df)
    if entity:
        df = df[df.entity == entity]
    if only_failures:
        df = df[df.status != "PASS"]
    return {"entity_scores": json.loads(scores[["dq_score"]].reset_index().to_json(orient="records")),
            "checks": json.loads(df.drop(columns=["run_ts"]).sort_values("pass_rate").to_json(orient="records"))}


def investigate_dq_failure(check_id: str) -> dict:
    return json.loads(json.dumps(rca.investigate(check_id, _con()), default=str))


def get_lineage(node: str, direction: str = "upstream") -> dict:
    tree = lineage.upstream(node) if direction == "upstream" else lineage.downstream(node)
    return {"node": node, "direction": direction, "tree": lineage.render(tree),
            "affected_kpis": lineage.affected_kpis(node) if direction == "downstream" else None}


def profile_dataset(table: str) -> list[dict]:
    if not re.fullmatch(r"(bronze|silver|gold)\.\w+", table):
        raise ValueError("table must look like layer.table_name")
    return json.loads(_con().execute(f"SUMMARIZE {table}").df().to_json(orient="records", default_handler=str))


_FORBIDDEN = re.compile(r"\b(insert|update|delete|drop|create|alter|attach|copy|pragma|install|load|export)\b", re.I)


def query_gold(sql: str, limit: int = 200) -> list[dict]:
    """Read-only SQL over gold.* tables only. Guardrails: SELECT-only, schema allow-list, row cap."""
    s = sql.strip().rstrip(";")
    if not re.match(r"(?is)^\s*(select|with)\b", s) or _FORBIDDEN.search(s) or ";" in s:
        raise ValueError("Only a single read-only SELECT is allowed.")
    tables = re.findall(r"(?i)\b(?:from|join)\s+([\w\.]+)", s)
    if any(not t.lower().startswith("gold.") for t in tables if not t.startswith("(")):
        raise ValueError("Only gold.* tables can be queried. Use the KPI tools for metrics.")
    return json.loads(_con().execute(f"SELECT * FROM ({s}) LIMIT {int(limit)}").df().to_json(orient="records", date_format="iso"))


TOOLS = {f.__name__: f for f in (search_knowledge, list_kpis, get_kpi_definition, get_schema, calculate_kpi,
                                 explain_kpi_change, assess_kpi_reliability, run_dq_checks,
                                 investigate_dq_failure, get_lineage, profile_dataset, query_gold)}

KPI_NAMES = list(md.load()["kpis"])
_S, _N, _B = {"type": "string"}, {"type": "integer"}, {"type": "boolean"}
_KPI = {"type": "string", "enum": KPI_NAMES}
_GRP = {"type": "string", "enum": ["week", "date", "vendor_code", "origin_hub_id"]}


def _schema(name, desc, props, req):
    return {"name": name, "description": desc, "input_schema": {"type": "object", "properties": props, "required": req}}


TOOL_SCHEMAS = [
    _schema("search_knowledge", "Search the data dictionary, KPI definitions, DQ rules and design docs. doc_type filters: entity, column, kpi, dq_rule, relationship, doc.",
            {"query": _S, "doc_type": _S, "k": _N}, ["query"]),
    _schema("list_kpis", "List all KPIs with module and description.", {}, []),
    _schema("get_kpi_definition", "Formula, gold table, DQ dependencies and upstream lineage of a KPI.", {"kpi": _KPI}, ["kpi"]),
    _schema("get_schema", "Data contract for a Silver entity (columns, keys, rules).", {"entity": _S}, ["entity"]),
    _schema("calculate_kpi", "Compute a KPI deterministically. Dates are YYYY-MM-DD.",
            {"kpi": _KPI, "start_date": _S, "end_date": _S, "group_by": _GRP, "vendor_code": _S}, ["kpi"]),
    _schema("explain_kpi_change", "Compare the latest window with the previous one and attribute the change to segments.",
            {"kpi": _KPI, "window_days": _N, "by": _GRP}, ["kpi"]),
    _schema("assess_kpi_reliability", "Evaluate the DQ checks a KPI depends on and return a reliability status.", {"kpi": _KPI}, ["kpi"]),
    _schema("run_dq_checks", "Run all DQ checks; returns entity DQ scores and failing checks.", {"entity": _S, "only_failures": _B}, []),
    _schema("investigate_dq_failure", "Root-cause evidence for one DQ check: concentration, onset week, orphan patterns, affected KPIs.",
            {"check_id": _S}, ["check_id"]),
    _schema("get_lineage", "Lineage of a KPI, table or entity. direction: upstream or downstream.",
            {"node": _S, "direction": {"type": "string", "enum": ["upstream", "downstream"]}}, ["node"]),
    _schema("profile_dataset", "Column-level profile (nulls, distinct, min/max) of layer.table.", {"table": _S}, ["table"]),
    _schema("query_gold", "Read-only SELECT over gold.* tables for ad-hoc questions not covered by KPI tools.", {"sql": _S}, ["sql"]),
]


def call(name: str, args: dict):
    return TOOLS[name](**(args or {}))
