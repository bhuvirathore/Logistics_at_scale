"""
Logistics Data Agent.

  question -> intent -> metadata retrieval (RAG) -> tool selection -> deterministic execution
           -> validation (reliability check) -> explanation

Two modes, same tools:
  * LLM mode (ANTHROPIC_API_KEY set): Claude plans and calls tools in a loop, then explains.
  * Offline mode: a deterministic planner runs fixed tool plans per intent and fills templates.
    Useful for tests, demos without a key, and as the baseline the LLM is evaluated against.
"""
from __future__ import annotations
import json
import re
from dataclasses import dataclass, field
from platform_core import metadata as md
from platform_core.config import LLM_ENABLED, LLM_MODEL
from platform_core.rag import index
from . import tools as T

SYSTEM_PROMPT = """You are a logistics data-platform agent for a Transport Management System lakehouse
(Bronze -> Silver -> Gold, KPIs across TAT, Adoption, Detention, Utilization, Payment & Cost).

Rules:
1. Never compute or estimate a number yourself. Every figure must come from a tool result.
2. Before reporting any KPI, call assess_kpi_reliability and state the reliability status.
   If it is not RELIABLE, say which dependency fails and how that biases the number.
3. For "why did X change" questions: explain_kpi_change -> assess_kpi_reliability ->
   investigate_dq_failure for failing dependencies -> separate real operational change from data artefacts.
4. Use search_knowledge to resolve business terms, then get_kpi_definition / get_schema for exact definitions.
5. Prefer KPI tools over query_gold. Percentages are always SUM(num)/SUM(den), never averages of percentages.
6. Answer in short paragraphs: finding, drivers, data-trust caveat, recommended next step."""


@dataclass
class AgentResult:
    question: str
    intent: str
    answer: str
    trace: list = field(default_factory=list)


INTENTS = [
    ("lineage", r"lineage|upstream|downstream|feeds?|contribut|what tables|depend|impact of|\bbreaks?\b|source of"),
    ("why_change", r"\bwhy\b|drop|declin|decreas|fell|fall|worse|improv|increase|went (up|down)|change"),
    ("dq", r"quality|\bdq\b|trust|reliab|integrity|orphan|missing|broken|gap|accurate|good enough|usable|sufficient"),
    ("definition", r"what is|what's|define|definition|how is .* (calculated|computed)|meaning|formula"),
]


def classify(q: str) -> str:
    ql = q.lower()
    for name, pat in INTENTS:
        if re.search(pat, ql):
            return name
    return "kpi_value"


class LogisticsDataAgent:
    def __init__(self, use_llm: bool | None = None):
        self.use_llm = LLM_ENABLED if use_llm is None else use_llm
        self.trace: list = []

    def _call(self, name: str, **args):
        out = T.call(name, args)
        self.trace.append({"tool": name, "args": args})
        return out

    # ------------------------------------------------------------------ public
    def ask(self, question: str) -> AgentResult:
        self.trace = []
        if self.use_llm:
            return AgentResult(question, "llm", self._ask_llm(question), self.trace)
        intent = classify(question)
        handler = getattr(self, f"_h_{intent}")
        return AgentResult(question, intent, handler(question), self.trace)

    # ------------------------------------------------------------------ LLM mode
    def _ask_llm(self, question: str, max_steps: int = 10) -> str:
        import anthropic
        client = anthropic.Anthropic()
        messages = [{"role": "user", "content": question}]
        for _ in range(max_steps):
            resp = client.messages.create(model=LLM_MODEL, max_tokens=2000, system=SYSTEM_PROMPT,
                                          tools=T.TOOL_SCHEMAS, messages=messages)
            messages.append({"role": "assistant", "content": resp.content})
            if resp.stop_reason != "tool_use":
                return "".join(b.text for b in resp.content if b.type == "text")
            results = []
            for b in resp.content:
                if b.type == "tool_use":
                    try:
                        out, err = self._call(b.name, **b.input), False
                    except Exception as e:          # tool errors go back to the model, not the user
                        out, err = {"error": str(e)}, True
                    results.append({"type": "tool_result", "tool_use_id": b.id,
                                    "content": json.dumps(out, default=str)[:20000], "is_error": err})
            messages.append({"role": "user", "content": results})
        return "Stopped: too many tool steps. Try a narrower question."

    # ------------------------------------------------------------------ offline planner
    def _kpi(self, q: str) -> str | None:
        k = index().resolve_kpi(q)
        self.trace.append({"tool": "search_knowledge(resolve_kpi)", "args": {"query": q}, "result": k})
        return k

    @staticmethod
    def _fmt(kpi: str, v) -> str:
        unit = md.kpi(kpi)["unit"]
        return "n/a" if v is None else f"{v:.1f}%" if unit == "pct" else f"{v:.2f} h" if unit == "hours" else f"{v:.2f}/kg"

    def _reliability_text(self, rel: dict) -> str:
        bad = [d for d in rel["dependencies"] if d["status"] != "PASS"]
        txt = f"Reliability: {rel['reliability']}."
        for d in bad:
            txt += f"\n  - {d['check_id']}: {d['pass_rate']:.1%} pass ({d['failing_rows']:,} failing rows) — {d['description']}"
        return txt

    def _rca_text(self, ev: dict) -> str:
        lines = [f"Root-cause evidence for {ev['check']['check_id']} ({ev['check']['pass_rate']:.1%} pass):"]
        lines += [f"  - {h}" for h in ev.get("hypotheses", [])] or ["  - No single concentrated cause found."]
        if ev.get("affected_kpis"):
            lines.append(f"  - KPIs affected: {', '.join(ev['affected_kpis'])}")
        return "\n".join(lines)

    def _h_why_change(self, q: str) -> str:
        kpi = self._kpi(q)
        if not kpi:
            return self._h_search(q)
        ch = self._call("explain_kpi_change", kpi=kpi)
        rel = self._call("assess_kpi_reliability", kpi=kpi)
        g = ch["by"]
        direction = "rose" if ch["change"] > 0 else "fell"
        out = [f"{kpi} {direction} from {self._fmt(kpi, ch['prior_value'])} ({ch['prior_period']}) "
               f"to {self._fmt(kpi, ch['recent_value'])} ({ch['recent_period']}), a change of {ch['change']:+.2f}."]
        segs = ch["segments"]
        movers = sorted(segs, key=lambda s: s["contribution"], reverse=ch["change"] > 0)[:3]  # biggest push in the direction of change
        out.append("Largest contributors (" + g + "):")
        for s in movers:
            out.append(f"  - {s[g]}: {self._fmt(kpi, s[kpi + '_prior'])} -> {self._fmt(kpi, s[kpi + '_recent'])} "
                       f"(contribution {s['contribution']:+.2f} pts, {int(s['denominator_recent']):,} trips in window)")
        out.append(self._reliability_text(rel))
        failing = [d["check_id"] for d in rel["dependencies"] if d["status"] != "PASS"]
        if failing:
            ev = self._call("investigate_dq_failure", check_id=failing[0])
            out.append(self._rca_text(ev))
            top = str(movers[0][g]) if movers else None
            hit = next((o for o in ev.get("segment_onsets", []) if o["segment"] == top), None)
            if hit:
                out.append(f"Interpretation: {top} drives both the KPI change and the data gap. Its delivery-event coverage "
                           f"collapsed from the week of {hit['onset_week']}, so the KPI for {top} is computed on a shrinking, "
                           f"possibly unrepresentative subset of trips. Part of the decline is likely real (longer transit), part "
                           f"is a measurement artefact. Fix the {top} feed and backfill before re-baselining {kpi}.")
        return "\n".join(out)

    def _h_dq(self, q: str) -> str:
        kpi = self._kpi(q)
        if kpi:
            rel = self._call("assess_kpi_reliability", kpi=kpi)
            out = [f"Can {kpi} be trusted? " + self._reliability_text(rel)]
            for d in [d for d in rel["dependencies"] if d["status"] != "PASS"][:2]:
                out.append(self._rca_text(self._call("investigate_dq_failure", check_id=d["check_id"])))
            return "\n".join(out)
        res = self._call("run_dq_checks")
        out = ["DQ scores (lowest first): " + ", ".join(f"{s['entity']} {s['dq_score']}" for s in res["entity_scores"][:5]),
               "Worst checks:"]
        out += [f"  - {c['check_id']} [{c['dimension']}] {c['pass_rate']:.1%} — {c['description']}" for c in res["checks"][:6]]
        return "\n".join(out)

    def _h_lineage(self, q: str) -> str:
        node = self._kpi(q)
        if not node:
            names = list(md.load()["entities"]) + list(md.load()["gold_tables"])
            node = next((n for n in sorted(names, key=len, reverse=True) if n in q.lower().replace(" ", "_")), None)
        if not node:
            return self._h_search(q)
        down = bool(re.search(r"impact|breaks?|downstream|affect", q.lower())) and node not in md.load()["kpis"]
        res = self._call("get_lineage", node=node, direction="downstream" if down else "upstream")
        txt = f"{'Downstream impact' if down else 'Upstream lineage'} of {node}:\n{res['tree']}"
        if down:
            txt += f"\nKPIs affected if {node} degrades: {', '.join(res['affected_kpis'])}"
        return txt

    def _h_definition(self, q: str) -> str:
        kpi = self._kpi(q)
        if kpi:
            d = self._call("get_kpi_definition", kpi=kpi)
            return (f"{kpi} ({d['module']}): {d['description']}\nFormula: SUM({d['numerator']}) / NULLIF(SUM({d['denominator']}), 0) "
                    f"on gold.{d['gold_table']}.\nGuarded by DQ checks: {', '.join(d['dq_dependencies'])}.\nLineage:\n{d['lineage']}")
        return self._h_search(q)

    def _h_kpi_value(self, q: str) -> str:
        kpi = self._kpi(q)
        if not kpi:
            return self._h_search(q)
        total = self._call("calculate_kpi", kpi=kpi)[0]
        weekly = self._call("calculate_kpi", kpi=kpi, group_by="week")[-4:]
        rel = self._call("assess_kpi_reliability", kpi=kpi)
        wk = ", ".join(f"{w['trip_week'][:10]}: {self._fmt(kpi, w[kpi])}" for w in weekly)
        return f"{kpi} overall: {self._fmt(kpi, total[kpi])}.\nLast 4 weeks: {wk}.\n{self._reliability_text(rel)}"

    def _h_search(self, q: str) -> str:
        hits = self._call("search_knowledge", query=q, k=3)
        return "Closest knowledge-base entries:\n" + "\n".join(f"  - {h['text']}" for h in hits) if hits else "No match found."
