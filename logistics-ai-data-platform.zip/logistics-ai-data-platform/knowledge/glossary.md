# Logistics glossary

## TAT (Turnaround Time)
Time-based performance of trips: on-time dispatch, transit time and on-time delivery against the planned SLA.

## Detention
Time a vehicle waits at a plant or depot beyond the free time allowed, measured from GATE_IN to GATE_OUT. Detention cannot be measured without gate events.

## Utilization
How full a vehicle is relative to its rated capacity. Low utilization means paying for empty space.

## Adoption
How consistently trips are tracked in the TMS. Low adoption means the operational truth is not visible in the data.

## Payment and cost
Freight cost from ERP freight bills (TCN) joined to TMS trips via the trip reference number. If the TCN match rate is low, cost KPIs only describe a biased subset of trips.

## TCN
Transportation Consignment Note, the ERP document number for a freight bill.

## Referential integrity
Every foreign key value in a child table exists in its parent table. Orphans silently disappear from inner joins in the Gold layer.

## Chain integrity
A multi-hop relationship (consignment to trip to vehicle to vendor to hub) resolves end to end. Each hop can pass on its own while the full chain still breaks.
