# Design principles

## Deterministic execution, LLM reasoning
The LLM never computes a KPI, writes to a table or decides whether data passes a check. It classifies the question, retrieves metadata, chooses tools, and explains tool results. Every number in an answer comes from a deterministic tool (SQL, DQ engine, KPI engine).

## KPI aggregation rule
Percentage KPIs are always computed as SUM(numerator) / NULLIF(SUM(denominator), 0) at the requested grain. Averaging pre-computed percentages across days, hubs or carriers is wrong because it weights small and large segments equally.

## Trust before insight
A KPI is only reported together with its reliability status. Reliability is the pass rate of the weakest data-quality check the KPI depends on: RELIABLE at 95% or more, USE_WITH_CAUTION from 80% to 95%, UNRELIABLE below 80%, BLOCKED below 5%.

## Resolution over rejection
When a key is sparsely populated at source, Silver resolves it through a more reliable path instead of dropping rows: consignment to trip through the task table, carrier through the vehicle master. Each resolved column keeps a *_source column so lineage stays explainable.

## Metadata-driven
Data contracts (entities.yaml), relationships and coverage checks (relationships.yaml) and the KPI semantic layer (kpis.yaml) are the single source of truth. The DQ engine, lineage graph, RAG index, MCP tools and Unity Catalog comments are generated from them.
