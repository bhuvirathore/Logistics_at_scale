# Project story (portfolio context)

## Origin
This platform is a synthetic reconstruction of an enterprise logistics analytics programme where a Transport Management System streamed operational data through Kafka CDC into a Databricks medallion lakehouse, joined with ERP freight bills, to produce KPIs across five modules: TAT, Adoption, Detention, Utilization, and Payment and Cost. No proprietary schema, code or data is included; the data is generated and the defects are re-created as configurable parameters.

## The core finding
Ingesting data was not the hard part. Reverse-engineering the source schema into an ER model and building a referential-integrity framework showed that missing events, sparsely populated keys, orphan master data and weak cross-system matching would silently distort downstream KPIs. The platform therefore treats data trust as a first-class output alongside the KPI itself.

## What the modern version adds
Data contracts, a scored DQ engine, a KPI impact engine, metadata-derived lineage, retrieval over the knowledge base, an agent that investigates KPI changes and DQ failures, and an MCP server that exposes every capability as a tool.
