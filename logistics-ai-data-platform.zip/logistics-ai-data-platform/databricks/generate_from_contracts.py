"""
Port the metadata layer to Databricks: generate from the same YAML contracts
  1. Unity Catalog COMMENT statements (tables + columns)  -> feeds Genie / AI-BI context
  2. Lakeflow Declarative Pipelines (DLT) expectations     -> enforce contracts in Silver
  3. Genie Space instructions for each KPI                -> consistent metric definitions

Usage: python -m databricks.generate_from_contracts --catalog logistics_demo > databricks/generated.sql
"""
import argparse
from platform_core import metadata as md


def uc_comments(catalog: str) -> list[str]:
    out = []
    for name, e in md.load()["entities"].items():
        tbl = f"{catalog}.{e['table']}"
        out.append(f"COMMENT ON TABLE {tbl} IS '{e['description'].replace(chr(39), '')}';")
        for col, c in e.get("columns", {}).items():
            out.append(f"ALTER TABLE {tbl} ALTER COLUMN {col} COMMENT '{c.get('description', '').replace(chr(39), '')}';")
    return out


def dlt_expectations() -> list[str]:
    out = []
    for name, e in md.load()["entities"].items():
        exp = [f'"{col}_not_null": "{col} IS NOT NULL"' for col, c in e.get("columns", {}).items() if c.get("required")]
        exp += [f'"{r["id"]}": "{r["expr"]}"' for r in e.get("rules", [])]
        if exp:
            out.append(f"# silver.{name}\n@dlt.expect_all({{{', '.join(exp)}}})")
    return out


def genie_instructions() -> list[str]:
    out = ["-- Genie Space instructions (paste into 'Instructions'):"]
    for k, v in md.load()["kpis"].items():
        out.append(f"-- {k} ({', '.join(v.get('aliases', []))}): {v['description']} "
                   f"Always compute as SUM({v['numerator']}) / NULLIF(SUM({v['denominator']}), 0) on {v['gold_table']}; never average percentages.")
    return out


if __name__ == "__main__":
    a = argparse.ArgumentParser(); a.add_argument("--catalog", default="logistics_demo"); args = a.parse_args()
    print("-- 1. Unity Catalog comments"); print("\n".join(uc_comments(args.catalog)))
    print("\n'''\n2. DLT expectations (Python)\n" + "\n\n".join(dlt_expectations()) + "\n'''")
    print("\n" + "\n".join(genie_instructions()))
