-- 1. Unity Catalog comments
COMMENT ON TABLE logistics_demo.silver.trip IS 'One vehicle movement from an origin plant. Grain = one row per trip.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN trip_id COMMENT 'Surrogate key of the trip in the TMS.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN trip_reference_number COMMENT 'Business reference shared with the ERP; joins to freight_bill.trip_reference_number (the TCN link).';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN origin_hub_id COMMENT 'Plant the trip departs from.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN vehicle_id COMMENT 'Vehicle assigned to the trip.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN vendor_code COMMENT 'Carrier as captured on the trip itself. Sparsely populated at source; use vendor_code_resolved.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN vendor_code_resolved COMMENT 'Carrier resolved from the trip or, failing that, from the vehicle master.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN planned_start COMMENT 'Planned dispatch time.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN planned_end COMMENT 'Planned delivery time (SLA).';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN actual_start COMMENT 'Actual dispatch time.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN actual_end COMMENT 'Actual trip close time from the TMS.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN planned_load_kg COMMENT 'Planned load on the vehicle in kg.';
ALTER TABLE logistics_demo.silver.trip ALTER COLUMN business_unit COMMENT 'Business unit (BEV, FOODS, HPC). Needed for BU-level slicing.';
COMMENT ON TABLE logistics_demo.silver.trip_event IS 'Milestone events emitted by the TMS / tracking provider. Grain = one row per event.';
ALTER TABLE logistics_demo.silver.trip_event ALTER COLUMN event_id COMMENT 'Event key.';
ALTER TABLE logistics_demo.silver.trip_event ALTER COLUMN trip_id COMMENT 'Trip the event belongs to.';
ALTER TABLE logistics_demo.silver.trip_event ALTER COLUMN event_type COMMENT 'Milestone type.';
ALTER TABLE logistics_demo.silver.trip_event ALTER COLUMN event_ts COMMENT 'Event timestamp.';
COMMENT ON TABLE logistics_demo.silver.task IS 'Bridge between consignments and trips. The reliable route from a consignment to its trip.';
ALTER TABLE logistics_demo.silver.task ALTER COLUMN task_id COMMENT 'Task key.';
ALTER TABLE logistics_demo.silver.task ALTER COLUMN trip_id COMMENT 'Trip that carries the consignment.';
ALTER TABLE logistics_demo.silver.task ALTER COLUMN consignment_id COMMENT 'Consignment carried.';
COMMENT ON TABLE logistics_demo.silver.consignment IS 'A customer shipment. One trip carries 1..n consignments.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN consignment_id COMMENT 'Consignment key.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN trip_id COMMENT 'Trip as captured on the consignment. Rarely populated at source.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN resolved_trip_id COMMENT 'Trip resolved directly or via the task table.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN sender_hub_id COMMENT 'Hub that sends the consignment.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN destination_hub_id COMMENT 'Destination hub. Needed for lane-level analysis.';
ALTER TABLE logistics_demo.silver.consignment ALTER COLUMN weight_kg COMMENT 'Consignment weight.';
COMMENT ON TABLE logistics_demo.silver.freight_bill IS 'Freight bill (TCN) from the ERP. Joins to the TMS via trip_reference_number.';
ALTER TABLE logistics_demo.silver.freight_bill ALTER COLUMN tcn COMMENT 'Transportation Consignment Note number (ERP key).';
ALTER TABLE logistics_demo.silver.freight_bill ALTER COLUMN trip_reference_number COMMENT 'TMS trip reference captured on the bill.';
ALTER TABLE logistics_demo.silver.freight_bill ALTER COLUMN estimated_freight COMMENT 'Estimated freight cost.';
ALTER TABLE logistics_demo.silver.freight_bill ALTER COLUMN actual_freight COMMENT 'Billed freight cost.';
COMMENT ON TABLE logistics_demo.silver.hub_master IS 'Plants and depots.';
ALTER TABLE logistics_demo.silver.hub_master ALTER COLUMN hub_id COMMENT 'Hub key.';
COMMENT ON TABLE logistics_demo.silver.vendor_master IS 'Carriers.';
ALTER TABLE logistics_demo.silver.vendor_master ALTER COLUMN vendor_code COMMENT 'Carrier key.';
COMMENT ON TABLE logistics_demo.silver.vehicle_master IS 'Vehicles and rated capacity.';
ALTER TABLE logistics_demo.silver.vehicle_master ALTER COLUMN vehicle_id COMMENT 'Vehicle key.';
ALTER TABLE logistics_demo.silver.vehicle_master ALTER COLUMN capacity_kg COMMENT 'Rated capacity in kg.';

'''
2. DLT expectations (Python)
# silver.trip
@dlt.expect_all({"trip_id_not_null": "trip_id IS NOT NULL", "trip_reference_number_not_null": "trip_reference_number IS NOT NULL", "origin_hub_id_not_null": "origin_hub_id IS NOT NULL", "vehicle_id_not_null": "vehicle_id IS NOT NULL", "vendor_code_resolved_not_null": "vendor_code_resolved IS NOT NULL", "planned_start_not_null": "planned_start IS NOT NULL", "planned_end_not_null": "planned_end IS NOT NULL", "actual_start_not_null": "actual_start IS NOT NULL", "planned_load_kg_not_null": "planned_load_kg IS NOT NULL", "trip_end_after_start": "actual_end IS NULL OR actual_end >= actual_start", "trip_load_positive": "planned_load_kg > 0"})

# silver.trip_event
@dlt.expect_all({"event_id_not_null": "event_id IS NOT NULL", "trip_id_not_null": "trip_id IS NOT NULL", "event_type_not_null": "event_type IS NOT NULL", "event_ts_not_null": "event_ts IS NOT NULL"})

# silver.task
@dlt.expect_all({"task_id_not_null": "task_id IS NOT NULL", "trip_id_not_null": "trip_id IS NOT NULL", "consignment_id_not_null": "consignment_id IS NOT NULL"})

# silver.consignment
@dlt.expect_all({"consignment_id_not_null": "consignment_id IS NOT NULL", "resolved_trip_id_not_null": "resolved_trip_id IS NOT NULL", "sender_hub_id_not_null": "sender_hub_id IS NOT NULL", "weight_kg_not_null": "weight_kg IS NOT NULL", "consignment_weight_positive": "weight_kg > 0"})

# silver.freight_bill
@dlt.expect_all({"tcn_not_null": "tcn IS NOT NULL", "trip_reference_number_not_null": "trip_reference_number IS NOT NULL", "actual_freight_not_null": "actual_freight IS NOT NULL", "bill_cost_components_le_total": "fuel_cost + toll_cost <= actual_freight * 1.2"})

# silver.hub_master
@dlt.expect_all({"hub_id_not_null": "hub_id IS NOT NULL"})

# silver.vendor_master
@dlt.expect_all({"vendor_code_not_null": "vendor_code IS NOT NULL"})

# silver.vehicle_master
@dlt.expect_all({"vehicle_id_not_null": "vehicle_id IS NOT NULL", "capacity_kg_not_null": "capacity_kg IS NOT NULL"})
'''

-- Genie Space instructions (paste into 'Instructions'):
-- on_time_delivery_pct (OTD, on time delivery, delivery SLA, on-time delivery): Share of delivered trips whose DELIVERED event is within 2 hours of the planned end time. Always compute as SUM(otd_num) / NULLIF(SUM(otd_den), 0) on gold_tat_trip_level; never average percentages.
-- on_time_dispatch_pct (on time dispatch, dispatch adherence, OTDisp): Share of trips dispatched within 1 hour of the planned start. Always compute as SUM(otdisp_num) / NULLIF(SUM(otdisp_den), 0) on gold_tat_trip_level; never average percentages.
-- avg_detention_hours (detention, dwell time, plant detention, gate to gate): Average hours a vehicle waits at the plant beyond 2 free hours, from GATE_IN to GATE_OUT. Always compute as SUM(detention_hours) / NULLIF(SUM(has_gate_pair), 0) on gold_detention_trip_level; never average percentages.
-- vehicle_utilization_pct (utilization, load factor, capacity utilization, fill rate): Planned load as a share of rated vehicle capacity. Always compute as SUM(planned_load_kg) / NULLIF(SUM(capacity_kg), 0) on gold_utilization_trip_level; never average percentages.
-- tracking_adoption_pct (adoption, tracking adoption, visibility, tracked trips): Share of trips with at least two tracking events. Always compute as SUM(is_tracked) / NULLIF(SUM(1), 0) on gold_adoption_trip_level; never average percentages.
-- freight_cost_per_kg (cost per kg, freight cost, transport cost, freight per kg): Billed freight divided by planned load, for trips matched to an ERP freight bill. Always compute as SUM(actual_freight) / NULLIF(SUM(CASE WHEN is_bill_matched = 1 THEN planned_load_kg END), 0) on gold_payment_trip_level; never average percentages.
-- bill_match_rate_pct (TCN match, bill match, invoice match, ERP match rate): Share of completed trips that have a matching ERP freight bill. Always compute as SUM(is_bill_matched) / NULLIF(SUM(is_completed), 0) on gold_payment_trip_level; never average percentages.
