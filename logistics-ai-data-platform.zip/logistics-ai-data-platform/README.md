# AI-Powered Logistics Data Quality & Intelligence Platform

> A data platform that doesn't just calculate KPIs — it determines whether the underlying data can be trusted.

**Disclaimer:** a synthetic reconstruction inspired by an enterprise Transport Management System (TMS) analytics programme. All data is generated; no proprietary schema, code, documents or data are included.

## The problem this solves
A TMS streams operational data (trips, milestone events, consignments) through Kafka CDC into a lakehouse, joined with ERP freight bills, to drive KPIs across five modules: **TAT, Adoption, Detention, Utilization, Payment & Cost**. Ingestion is the easy part. Missing events, sparsely populated keys, orphan master data and weak cross-system matching silently distort KPIs, and a dashboard shows a wrong number with full confidence.

This platform makes **data trust a first-class output**: every KPI is reported with a reliability status traced back to the exact data-quality checks it depends on, and an agent can explain *why* a KPI moved and whether the move is real or a data artefact.

## Architecture
```mermaid
flowchart LR
  K[TMS Kafka CDC + ERP bills] --> B[Bronze: raw, immutable]
  B --> S[Silver: cleaned, deduped, keys resolved]
  S --> G[Gold: KPI-ready star tables]
  C[(Data contracts YAML)] -.-> DQ[DQ Engine]
  S --> DQ --> R[(ops.dq_results)]
  G --> KPI[KPI Engine + Impact Engine]
  R --> KPI
  C -.-> L[Lineage graph] & RAG[Knowledge index]
  KPI & L & RAG & DQ --> T[Tool registry]
  T --> A[Data Agent: LLM reasoning]
  T --> M[MCP server]
```
The LLM never computes a number. It classifies, retrieves, chooses tools and explains; SQL, DQ checks and KPI maths are deterministic.

## Quickstart
```bash
pip install -r requirements.txt
python main.py build          # synthetic data -> bronze -> silver -> gold -> DQ run
python main.py kpis           # every KPI with its reliability status
python main.py demo           # scripted agent walkthrough
python main.py ask "Why did on-time delivery decline last month?"
python -m evaluation.run_eval # agent eval: intent, KPI resolution, tool recall
python -m mcp_server.server   # expose tools to any MCP client
export ANTHROPIC_API_KEY=...  # optional: switches the agent to LLM tool-use mode
```

## What the agent finds (offline mode, synthetic data)
```
on_time_delivery_pct fell from 68.0% to 63.6%, a change of -4.45.
  - V007: 69.7% -> 15.2% (contribution -10.22 pts)
Reliability: UNRELIABLE.
  - delivered_event_coverage: 77.8% pass (1,279 failing rows)
Root-cause evidence:
  - vendor_code=V007: pass rate fell from 79% to 34% from the week of 2026-08-03
Interpretation: V007 drives both the KPI change and the data gap ... part real, part measurement artefact.
```

## Repository map
| Path | Role |
|---|---|
| `platform_core/generator.py` | Synthetic TMS + ERP data with configurable defect knobs |
| `platform_core/pipeline.py` | Bronze -> Silver -> Gold SQL (ports to Databricks SQL / DLT) |
| `metadata/*.yaml` | Data contracts, FK + coverage + chain-integrity checks, KPI semantic layer |
| `platform_core/dq_engine.py` | Contract-driven checks and dimension-weighted DQ score |
| `platform_core/kpi_engine.py` | KPI calc, period-over-period driver analysis, KPI impact/reliability |
| `platform_core/lineage.py` | Upstream lineage and downstream impact from metadata |
| `platform_core/rca.py` | Deterministic root-cause evidence (concentration, onset, orphan patterns) |
| `platform_core/rag.py` | Metadata-aware retrieval over contracts, KPIs and docs |
| `agents/tools.py` | Tool registry with guarded read-only SQL |
| `agents/data_agent.py` | Agent: LLM tool-use loop + deterministic offline planner |
| `mcp_server/server.py` | Same tools over MCP |
| `evaluation/` | Agent eval set and scorer |
| `databricks/generate_from_contracts.py` | Unity Catalog COMMENTs, DLT expectations, Genie instructions from the same YAML |

## Design decisions
1. **Percentage KPIs are SUM(num)/NULLIF(SUM(den),0)** at every grain. Averaging percentages is wrong.
2. **Resolution over rejection.** Sparse keys are resolved through a reliable path (consignment -> trip via task; carrier via vehicle master) with a `*_source` column for lineage.
3. **Chain integrity is checked separately from each FK.** Every hop can pass while the end-to-end chain still drops rows from Gold joins.
4. **KPI reliability = weakest dependency.** RELIABLE >= 95%, CAUTION 80-95%, UNRELIABLE < 80%, BLOCKED < 5%.
5. **One metadata source of truth** drives the DQ engine, lineage, RAG, MCP tools and Databricks artefacts.

## Running on Databricks
Bronze: Auto Loader / Kafka structured streaming into Delta. Silver/Gold: the SQL in `pipeline.py` as a Lakeflow Declarative Pipeline with expectations generated from the contracts. `ops.dq_results` becomes a Delta table behind an AI/BI DQ dashboard. Unity Catalog COMMENTs and Genie instructions are generated so Genie answers with the same metric definitions. Swap TF-IDF for Databricks Vector Search; register the agent with Mosaic AI Agent Framework, or point Genie/Claude at the MCP server.
