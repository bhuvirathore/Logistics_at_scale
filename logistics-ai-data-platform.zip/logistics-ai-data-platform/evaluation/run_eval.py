"""
Agent evaluation: intent accuracy, KPI-resolution accuracy, required-tool recall,
plus a deterministic 'numbers match the engine' check (no hallucinated figures).
Works in offline mode by default; pass --llm to score the LLM agent's tool use.
"""
import sys
import yaml
from pathlib import Path
from agents.data_agent import LogisticsDataAgent
from platform_core.rag import index


def main(use_llm: bool = False):
    cases = yaml.safe_load((Path(__file__).parent / "eval_set.yaml").read_text())
    agent = LogisticsDataAgent(use_llm=use_llm)
    score = {"intent": 0, "kpi": 0, "tools": 0}
    for c in cases:
        r = agent.ask(c["q"])
        called = {t["tool"] for t in r.trace}
        ok_i = use_llm or r.intent == c["intent"]
        ok_k = index().resolve_kpi(c["q"]) == c["kpi"]
        ok_t = all(t in called for t in c["tools"])
        score["intent"] += ok_i; score["kpi"] += ok_k; score["tools"] += ok_t
        print(f"{'✓' if ok_i and ok_k and ok_t else '✗'} {c['q'][:58]:<58} intent={r.intent:<10} tools={len(called)}")
    n = len(cases)
    print("\n" + "  ".join(f"{k}: {v}/{n}" for k, v in score.items()))


if __name__ == "__main__":
    main(use_llm="--llm" in sys.argv)
