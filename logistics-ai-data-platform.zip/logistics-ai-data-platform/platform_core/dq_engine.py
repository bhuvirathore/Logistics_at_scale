"""
Data Quality Engine — metadata-driven, deterministic.

Reads the data contracts and runs six families of checks:
  uniqueness | completeness | allowed values | referential (FK) | temporal/business rules
  | coverage & chain integrity
Results land in ops.dq_results (one row per check per run) and roll up to a
dimension-weighted DQ score per entity. Nothing here uses an LLM.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime
import duckdb
import pandas as pd
from . import metadata as md
from .config import WAREHOUSE

WEIGHTS = {"completeness": .30, "referential": .25, "uniqueness": .15,
           "chain_integrity": .10, "temporal": .10, "business": .10, "validity": .10}


@dataclass
class CheckResult:
    check_id: str
    entity: str
    dimension: str
    description: str
    population: int
    passed: int
    threshold: float

    @property
    def pass_rate(self) -> float:
        return self.passed / self.population if self.population else 1.0

    @property
    def status(self) -> str:
        if self.pass_rate >= self.threshold:
            return "PASS"
        return "FAIL" if self.pass_rate < self.threshold - 0.10 else "WARN"

    def to_dict(self):
        d = asdict(self)
        d.update(pass_rate=round(self.pass_rate, 4), status=self.status)
        return d


class DQEngine:
    def __init__(self, con: duckdb.DuckDBPyConnection | None = None):
        self.con = con or duckdb.connect(str(WAREHOUSE))
        self.meta = md.load()

    def _one(self, sql: str):
        return self.con.execute(sql).fetchone()

    # ---- check families -------------------------------------------------
    def _entity_checks(self, name: str, spec: dict) -> list[CheckResult]:
        t, out = spec["table"], []
        total = self._one(f"SELECT COUNT(*) FROM {t}")[0]
        pk = ", ".join(spec["primary_key"])
        distinct = self._one(f"SELECT COUNT(*) FROM (SELECT DISTINCT {pk} FROM {t})")[0]
        out.append(CheckResult(f"{name}_pk_unique", name, "uniqueness", f"Primary key ({pk}) is unique", total, distinct, 1.0))
        for col, c in spec.get("columns", {}).items():
            if c.get("required") or "expected_fill" in c:
                filled = self._one(f"SELECT COUNT({col}) FROM {t}")[0]
                thr = 0.99 if c.get("required") else c["expected_fill"]
                out.append(CheckResult(f"{name}_{col}_not_null", name, "completeness",
                                       f"{col} populated — {c.get('description', '')}", total, filled, thr))
            if "allowed" in c:
                vals = ", ".join(f"'{v}'" for v in c["allowed"])
                ok = self._one(f"SELECT COUNT(*) FROM {t} WHERE {col} IN ({vals})")[0]
                out.append(CheckResult(f"{name}_{col}_allowed", name, "validity", f"{col} in allowed set", total, ok, 1.0))
        for r in spec.get("rules", []):
            ok = self._one(f"SELECT COUNT(*) FROM {t} WHERE {r['expr']}")[0]
            out.append(CheckResult(r["id"], name, r["dimension"], r["description"], total, ok, 0.99))
        return out

    def _fk_check(self, rel: dict) -> CheckResult:
        ce, cc = rel["child"].split(".")
        pe, pc = rel["parent"].split(".")
        ct, pt = md.entity(ce)["table"], md.entity(pe)["table"]
        non_null, orphans = self._one(f"""
            SELECT COUNT(c.{cc}), COUNT(c.{cc}) FILTER (WHERE p.{pc} IS NULL)
            FROM {ct} c LEFT JOIN (SELECT DISTINCT {pc} FROM {pt}) p ON c.{cc} = p.{pc}""")
        return CheckResult(rel["id"], ce, "referential", f"{rel['child']} -> {rel['parent']} has no orphans",
                           non_null, non_null - orphans, 0.99)

    def _coverage_check(self, c: dict) -> CheckResult:
        pop, ok = self._one(f"""SELECT COUNT(*), COUNT(*) FILTER (WHERE {c['pass_condition']})
                               FROM {c['base']} WHERE {c['population']}""")
        return CheckResult(c["id"], c["entity"], c["dimension"], c["description"], pop, ok, c["threshold"])

    # ---- public API -----------------------------------------------------
    def run_all(self, persist: bool = True) -> pd.DataFrame:
        results = []
        for name, spec in self.meta["entities"].items():
            results += self._entity_checks(name, spec)
        results += [self._fk_check(r) for r in self.meta["relationships"]]
        results += [self._coverage_check(c) for c in self.meta["coverage_checks"]]
        df = pd.DataFrame([r.to_dict() for r in results])
        df["run_ts"] = datetime.now()
        if persist:
            self.con.execute("CREATE SCHEMA IF NOT EXISTS ops")
            self.con.register("dq", df)
            self.con.execute("CREATE TABLE IF NOT EXISTS ops.dq_results AS SELECT * FROM dq WHERE FALSE")
            self.con.execute("INSERT INTO ops.dq_results SELECT * FROM dq")
            self.con.unregister("dq")
        return df

    def run_one(self, check_id: str) -> CheckResult:
        if c := md.coverage_check(check_id):
            return self._coverage_check(c)
        if r := md.relationship(check_id):
            return self._fk_check(r)
        for name, spec in self.meta["entities"].items():
            for res in self._entity_checks(name, spec):
                if res.check_id == check_id:
                    return res
        raise KeyError(f"Unknown check: {check_id}")

    @staticmethod
    def scores(df: pd.DataFrame) -> pd.DataFrame:
        """Dimension-weighted DQ score per entity (0-100)."""
        dim = df.groupby(["entity", "dimension"]).pass_rate.mean().reset_index()
        dim["w"] = dim.dimension.map(WEIGHTS).fillna(.1)
        s = dim.groupby("entity").apply(lambda g: (g.pass_rate * g.w).sum() / g.w.sum(), include_groups=False)
        piv = dim.pivot(index="entity", columns="dimension", values="pass_rate").round(3)
        piv.insert(0, "dq_score", (s * 100).round(1))
        return piv.sort_values("dq_score")
