"""Central configuration. Everything is path-relative so the repo runs anywhere."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
METADATA_DIR = ROOT / "metadata"
KNOWLEDGE_DIR = ROOT / "knowledge"
WAREHOUSE = DATA_DIR / "warehouse.duckdb"   # stands in for Unity Catalog locally

# LLM settings — the platform works fully offline; the LLM is an optional reasoning layer.
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
LLM_ENABLED = bool(os.getenv("ANTHROPIC_API_KEY"))

# Reliability bands used by the KPI impact engine
RELIABLE, CAUTION = 0.95, 0.80
