"""Loads the YAML metadata (data contracts, relationships, KPIs) once and exposes it."""
from functools import lru_cache
import yaml
from .config import METADATA_DIR


@lru_cache
def load() -> dict:
    out = {}
    for f in ("entities", "relationships", "kpis"):
        out.update(yaml.safe_load((METADATA_DIR / f"{f}.yaml").read_text()))
    return out


def entity(name: str) -> dict:
    return load()["entities"][name]


def kpi(name: str) -> dict:
    return load()["kpis"][name]


def coverage_check(check_id: str) -> dict | None:
    return next((c for c in load()["coverage_checks"] if c["id"] == check_id), None)


def relationship(rel_id: str) -> dict | None:
    return next((r for r in load()["relationships"] if r["id"] == rel_id), None)


def kpis_depending_on(check_id: str) -> list[str]:
    return [k for k, v in load()["kpis"].items() if check_id in v.get("dq_dependencies", [])]
