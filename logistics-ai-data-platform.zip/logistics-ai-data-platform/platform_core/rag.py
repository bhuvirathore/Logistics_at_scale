"""
RAG over the data platform's own knowledge: contracts, columns, relationships,
DQ checks, KPI definitions and markdown docs. Each chunk carries metadata
(doc_type, entity, kpi, module) so retrieval can be filtered — the agent asks for
'kpi' chunks when resolving a KPI name and 'column' chunks when explaining a field.

Local implementation: TF-IDF (zero external services). Swap `_embed` for real
embeddings or Databricks Vector Search without touching callers.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from functools import lru_cache
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from . import metadata as md
from .config import KNOWLEDGE_DIR


@dataclass
class Chunk:
    text: str
    meta: dict = field(default_factory=dict)


def build_corpus() -> list[Chunk]:
    m, out = md.load(), []
    for name, e in m["entities"].items():
        out.append(Chunk(f"Entity {name} ({e['table']}): {e['description']} Primary key: {', '.join(e['primary_key'])}.",
                         {"doc_type": "entity", "entity": name}))
        for col, c in e.get("columns", {}).items():
            req = "required" if c.get("required") else f"optional, expected fill {c.get('expected_fill', 'n/a')}"
            out.append(Chunk(f"Column {name}.{col} ({req}): {c.get('description', '')}",
                             {"doc_type": "column", "entity": name, "column": col}))
        for r in e.get("rules", []):
            out.append(Chunk(f"DQ rule {r['id']} on {name} [{r['dimension']}]: {r['description']} Expression: {r['expr']}",
                             {"doc_type": "dq_rule", "entity": name, "check_id": r["id"]}))
    for r in m["relationships"]:
        out.append(Chunk(f"Relationship {r['id']}: {r['child']} references {r['parent']} (foreign key, referential integrity).",
                         {"doc_type": "relationship", "check_id": r["id"]}))
    for c in m["coverage_checks"]:
        out.append(Chunk(f"DQ check {c['id']} [{c['dimension']}] threshold {c['threshold']}: {c['description']}",
                         {"doc_type": "dq_rule", "entity": c["entity"], "check_id": c["id"]}))
    for k, v in m["kpis"].items():
        out.append(Chunk(
            f"KPI {k} ({v['module']} module). Also called: {', '.join(v.get('aliases', []))}. {v['description']} "
            f"Computed as SUM({v['numerator']}) / NULLIF(SUM({v['denominator']}), 0) on gold.{v['gold_table']}. "
            f"Depends on DQ checks: {', '.join(v.get('dq_dependencies', []))}.",
            {"doc_type": "kpi", "kpi": k, "module": v["module"]}))
    for f in sorted(KNOWLEDGE_DIR.glob("*.md")):
        for sec in re.split(r"\n(?=## )", f.read_text()):
            if sec.strip() and not sec.startswith("# "):
                out.append(Chunk(sec.strip(), {"doc_type": "doc", "source": f.name}))
    return out


class KnowledgeIndex:
    def __init__(self):
        self.chunks = build_corpus()
        self.vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, token_pattern=r"[A-Za-z0-9_]+")
        self.matrix = self.vec.fit_transform([self._norm(c.text) for c in self.chunks])

    @staticmethod
    def _norm(t: str) -> str:
        return t.lower().replace("-", " ")

    def search(self, query: str, k: int = 5, doc_type: str | None = None) -> list[dict]:
        sims = cosine_similarity(self.vec.transform([self._norm(query)]), self.matrix)[0]
        ranked = sorted(range(len(self.chunks)), key=lambda i: -sims[i])
        hits = [i for i in ranked if doc_type in (None, self.chunks[i].meta.get("doc_type"))][:k]
        return [{"score": round(float(sims[i]), 3), "text": self.chunks[i].text, **self.chunks[i].meta} for i in hits if sims[i] > 0]

    def resolve_kpi(self, query: str) -> str | None:
        q = self._norm(query)
        for k, v in md.load()["kpis"].items():          # exact alias match first, then semantic
            if k in q or any(re.search(rf"\b{re.escape(self._norm(a))}\b", q) for a in v.get("aliases", [])):
                return k
        hits = self.search(query, k=1, doc_type="kpi")
        return hits[0]["kpi"] if hits and hits[0]["score"] > 0.08 else None


@lru_cache
def index() -> KnowledgeIndex:
    return KnowledgeIndex()
