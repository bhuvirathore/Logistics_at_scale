"""
Deterministic root-cause investigator for a failing DQ check.

Produces *evidence* (concentration, onset date, orphan patterns, affected KPIs) and
rule-based hypotheses. The LLM layer only turns this evidence into prose; it never
invents the facts.
"""
from __future__ import annotations
import duckdb
from . import metadata as md, lineage
from .dq_engine import DQEngine


def _coverage_breakdown(con, c: dict, dim_name: str, dim_expr: str) -> list[dict]:
    df = con.execute(f"""
        SELECT {dim_expr} AS segment, COUNT(*) AS population,
               COUNT(*) FILTER (WHERE NOT COALESCE({c['pass_condition']}, FALSE)) AS failing
        FROM {c['base']} WHERE {c['population']} GROUP BY 1 ORDER BY 1""").df()
    df["pass_rate"] = (1 - df.failing / df.population).round(3)
    df["share_of_failures"] = (df.failing / max(df.failing.sum(), 1)).round(3)
    df["segment"] = df.segment.astype(str)
    return df.to_dict("records")


def _onset(weekly: list[dict], drop: float = 0.10) -> str | None:
    """First week whose pass rate falls > `drop` below the median of all earlier weeks."""
    for i in range(3, len(weekly)):
        base = sorted(w["pass_rate"] for w in weekly[:i])[i // 2]
        before = sum(w["pass_rate"] for w in weekly[:i]) / i
        after = sum(w["pass_rate"] for w in weekly[i:]) / (len(weekly) - i)
        if weekly[i]["pass_rate"] < base - drop and after < before - drop:   # sharp AND sustained
            return weekly[i]["segment"]
    return None


def _segment_onsets(con, c: dict) -> list[dict]:
    """For every non-time dimension, find segments whose weekly pass rate collapses at a specific week."""
    week = c["dims"].get("week")
    if not week:
        return []
    out = []
    for name, expr in c["dims"].items():
        if name == "week":
            continue
        df = con.execute(f"""
            SELECT {expr} AS segment, {week} AS wk, COUNT(*) AS population,
                   AVG(CASE WHEN COALESCE({c['pass_condition']}, FALSE) THEN 1.0 ELSE 0.0 END) AS pass_rate
            FROM {c['base']} WHERE {c['population']} GROUP BY 1, 2 HAVING COUNT(*) >= 10 ORDER BY 1, 2""").df()
        for seg, g in df.groupby("segment"):
            rows = [{"segment": str(w)[:10], "pass_rate": r} for w, r in zip(g.wk, g.pass_rate)]
            wk = _onset(rows, drop=0.25)
            if wk:
                i = [r["segment"] for r in rows].index(wk)
                before = sum(r["pass_rate"] for r in rows[:i]) / i
                after = sum(r["pass_rate"] for r in rows[i:]) / (len(rows) - i)
                out.append({"dimension": name, "segment": str(seg), "onset_week": wk,
                            "pass_rate_before": round(before, 3), "pass_rate_after": round(after, 3)})
    return sorted(out, key=lambda o: o["pass_rate_after"] - o["pass_rate_before"])


def investigate(check_id: str, con: duckdb.DuckDBPyConnection | None = None) -> dict:
    dq = DQEngine(con)
    con = dq.con
    res = dq.run_one(check_id)
    ev = {"check": res.to_dict(), "affected_kpis": md.kpis_depending_on(check_id), "hypotheses": []}

    if c := md.coverage_check(check_id):
        ev["breakdowns"] = {}
        for name, expr in c.get("dims", {}).items():
            rows = _coverage_breakdown(con, c, name, expr)
            if name == "week":
                ev["onset_week"] = _onset(rows)
                ev["breakdowns"][name] = rows
            else:
                ev["breakdowns"][name] = sorted(rows, key=lambda r: -r["share_of_failures"])[:5]
        overall = res.pass_rate
        for name, rows in ev["breakdowns"].items():
            if name == "week":
                continue
            worst = min(rows, key=lambda r: r["pass_rate"])
            if worst["pass_rate"] < overall - 0.15:
                ev["hypotheses"].append(
                    f"Failures are concentrated in {name}={worst['segment']} "
                    f"(pass rate {worst['pass_rate']:.0%} vs {overall:.0%} overall) — likely a segment-specific feed or process issue.")
        ev["segment_onsets"] = _segment_onsets(con, c)
        for o in ev["segment_onsets"][:3]:
            ev["hypotheses"].append(
                f"{o['dimension']}={o['segment']}: pass rate fell from {o['pass_rate_before']:.0%} to {o['pass_rate_after']:.0%} "
                f"from the week of {o['onset_week']} — a feed/integration change for this segment, not a network-wide issue.")
        if ev.get("onset_week"):
            ev["hypotheses"].append(f"Degradation starts in the week of {ev['onset_week']} — check source/feed changes around that date.")
        if overall < 0.10:
            ev["hypotheses"].append("Near-zero coverage across all segments — the source system is probably not emitting this data at all (a structural gap, not a pipeline bug).")

    elif r := md.relationship(check_id):
        ce, cc = r["child"].split("."); pe, pc = r["parent"].split(".")
        ct, pt = md.entity(ce)["table"], md.entity(pe)["table"]
        orphans = con.execute(f"""
            SELECT c.{cc} AS value, COUNT(*) AS rows FROM {ct} c
            WHERE c.{cc} IS NOT NULL AND c.{cc} NOT IN (SELECT {pc} FROM {pt} WHERE {pc} IS NOT NULL)
            GROUP BY 1 ORDER BY 2 DESC LIMIT 10""").df()
        prefixes = con.execute(f"""
            SELECT regexp_extract(CAST(c.{cc} AS VARCHAR), '^[A-Za-z]+', 0) AS prefix, COUNT(*) AS rows FROM {ct} c
            WHERE c.{cc} IS NOT NULL AND c.{cc} NOT IN (SELECT {pc} FROM {pt} WHERE {pc} IS NOT NULL)
            GROUP BY 1 ORDER BY 2 DESC LIMIT 5""").df()
        ev["top_orphan_values"] = orphans.to_dict("records")
        ev["orphan_key_prefixes"] = prefixes.to_dict("records")
        if len(orphans) and orphans.rows.iloc[0] / max(orphans.rows.sum(), 1) > 0.8:
            ev["hypotheses"].append(f"A single key ({orphans.value.iloc[0]}) causes most orphans — it exists as a reference "
                                    f"in {ce} but is missing from the {pe} master, so Gold joins silently drop it.")
        parent_prefix = con.execute(f"SELECT regexp_extract(CAST({pc} AS VARCHAR), '^[A-Za-z]+', 0) FROM {pt} LIMIT 1").fetchone()[0]
        odd = [p for p in prefixes.prefix if p and p != parent_prefix]
        if odd:
            ev["hypotheses"].append(f"Orphan keys use prefix(es) {odd} unlike the master's '{parent_prefix}' — suggests manually keyed or "
                                    f"non-system references; a mapping table or source-side validation is needed.")
        ev["affected_kpis"] = sorted(set(ev["affected_kpis"]) | set(lineage.affected_kpis(md.entity(ce)["table"])))
    return ev
