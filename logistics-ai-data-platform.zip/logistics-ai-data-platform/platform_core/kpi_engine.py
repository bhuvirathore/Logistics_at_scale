"""
KPI engine = semantic layer + driver analysis + KPI *impact* engine.

calculate()      deterministic KPI at any grain (always SUM(num)/NULLIF(SUM(den),0))
compare_periods() splits a KPI change into per-segment contributions
assess_impact()  answers "can this number be trusted?" by evaluating the DQ checks
                 the KPI depends on (from kpis.yaml -> dq_dependencies)
"""
from __future__ import annotations
from datetime import timedelta
import duckdb
import pandas as pd
from . import metadata as md
from .config import WAREHOUSE, RELIABLE, CAUTION
from .dq_engine import DQEngine

GROUPABLE = {"week": "trip_week", "trip_week": "trip_week", "date": "trip_date", "trip_date": "trip_date",
             "vendor": "vendor_code", "vendor_code": "vendor_code", "carrier": "vendor_code",
             "hub": "origin_hub_id", "origin_hub_id": "origin_hub_id", "plant": "origin_hub_id"}


class KPIEngine:
    def __init__(self, con: duckdb.DuckDBPyConnection | None = None):
        self.con = con or duckdb.connect(str(WAREHOUSE))
        self.dq = DQEngine(self.con)

    def _expr(self, k: dict) -> tuple[str, str, str]:
        num, den = f"SUM({k['numerator']})", f"SUM({k['denominator']})"
        scale = "100.0 * " if k["unit"] == "pct" else "1.0 * "
        return f"ROUND({scale}{num} / NULLIF({den}, 0), 2)", num, den

    def calculate(self, kpi: str, start_date: str | None = None, end_date: str | None = None,
                  group_by: str | None = None, vendor_code: str | None = None) -> pd.DataFrame:
        k = md.kpi(kpi)
        value, num, den = self._expr(k)
        where = ["1=1"]
        if start_date: where.append(f"trip_date >= DATE '{start_date}'")
        if end_date:   where.append(f"trip_date <= DATE '{end_date}'")
        if vendor_code: where.append(f"vendor_code = '{vendor_code.replace(chr(39), '')}'")
        g = GROUPABLE.get(group_by or "", None)
        sel = f"{g}, " if g else ""
        sql = (f"SELECT {sel}{value} AS {kpi}, {num} AS numerator, {den} AS denominator, COUNT(*) AS rows "
               f"FROM gold.{k['gold_table']} WHERE {' AND '.join(where)}"
               + (f" GROUP BY {g} ORDER BY {g}" if g else ""))
        return self.con.execute(sql).df()

    def date_bounds(self, kpi: str):
        return self.con.execute(f"SELECT MIN(trip_date), MAX(trip_date) FROM gold.{md.kpi(kpi)['gold_table']}").fetchone()

    def compare_periods(self, kpi: str, window_days: int = 28, by: str = "vendor_code") -> dict:
        """Recent window vs the window before it, decomposed into segment contributions."""
        _, end = self.date_bounds(kpi)
        r0, p0 = end - timedelta(days=window_days - 1), end - timedelta(days=2 * window_days - 1)
        p1 = r0 - timedelta(days=1)
        rec = self.calculate(kpi, str(r0), str(end), by)
        pri = self.calculate(kpi, str(p0), str(p1), by)
        tot_r = self.calculate(kpi, str(r0), str(end)).iloc[0]
        tot_p = self.calculate(kpi, str(p0), str(p1)).iloc[0]
        g = GROUPABLE[by]
        m = rec.merge(pri, on=g, suffixes=("_recent", "_prior"), how="outer").fillna(0)
        # mix-aware contribution: (den share * rate) recent - prior. Sums to the total change.
        for s, tot in (("recent", tot_r), ("prior", tot_p)):
            m[f"share_{s}"] = m[f"denominator_{s}"] / max(float(tot.denominator or 0), 1)
            m[f"wrate_{s}"] = m[f"share_{s}"] * m[f"{kpi}_{s}"]
        m["contribution"] = (m.wrate_recent - m.wrate_prior).round(2)
        m["rate_change"] = (m[f"{kpi}_recent"] - m[f"{kpi}_prior"]).round(2)
        m = m.sort_values("contribution")
        return {"kpi": kpi, "recent_period": f"{r0} to {end}", "prior_period": f"{p0} to {p1}",
                "recent_value": float(tot_r[kpi]), "prior_value": float(tot_p[kpi]),
                "change": round(float(tot_r[kpi]) - float(tot_p[kpi]), 2),
                "by": g, "segments": m[[g, f"{kpi}_prior", f"{kpi}_recent", "rate_change",
                                         "denominator_recent", "contribution"]].to_dict("records")}

    def assess_impact(self, kpi: str) -> dict:
        """KPI reliability = weakest DQ dependency. Turns 'X rows failed' into 'KPI Y is unreliable'."""
        deps = []
        for cid in md.kpi(kpi).get("dq_dependencies", []):
            r = self.dq.run_one(cid)
            deps.append({"check_id": cid, "description": r.description, "pass_rate": round(r.pass_rate, 4),
                         "failing_rows": r.population - r.passed, "status": r.status})
        worst = min((d["pass_rate"] for d in deps), default=1.0)
        status = ("BLOCKED" if worst < 0.05 else "RELIABLE" if worst >= RELIABLE
                  else "USE_WITH_CAUTION" if worst >= CAUTION else "UNRELIABLE")
        return {"kpi": kpi, "reliability": status, "weakest_pass_rate": worst, "dependencies": deps}
