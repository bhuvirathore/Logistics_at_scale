"""
Medallion pipeline: BRONZE (raw CDC) -> SILVER (clean, conformed, resolved) -> GOLD (KPI-ready).

The SQL is written to port almost 1:1 to Databricks SQL / DLT. Two "resolution"
patterns from the original project are encoded explicitly in Silver:
  * consignment -> trip resolved via the task table when consignment.trip_id is NULL
  * trip vendor resolved via vehicle master when trip.vendor_code is NULL
Every resolved column carries a *_source column so lineage stays explainable.
"""
import duckdb
from .config import WAREHOUSE

SILVER = {
"hub_master":     "SELECT DISTINCT hub_id, hub_name, hub_type, city, pincode FROM bronze.hub_master",
"vendor_master":  "SELECT DISTINCT vendor_code, vendor_name, vendor_type FROM bronze.vendor_master",
"vehicle_master": "SELECT DISTINCT vehicle_id, vehicle_type, capacity_kg, vendor_code FROM bronze.vehicle_master",
"trip": """
    SELECT t.trip_id, t.trip_reference_number, t.origin_hub_id, t.vehicle_id,
           t.vendor_code,
           COALESCE(t.vendor_code, v.vendor_code)                         AS vendor_code_resolved,
           CASE WHEN t.vendor_code IS NOT NULL THEN 'trip'
                WHEN v.vendor_code IS NOT NULL THEN 'vehicle_master' END AS vendor_code_source,
           t.planned_start, t.planned_end, t.actual_start, t.actual_end,
           t.planned_load_kg, t.business_unit
    FROM bronze.trip t LEFT JOIN bronze.vehicle_master v USING (vehicle_id)""",
"trip_event": """
    SELECT * EXCLUDE (rn) FROM (
        SELECT event_id, trip_id, event_type, event_ts, hub_id,
               ROW_NUMBER() OVER (PARTITION BY trip_id, event_type, event_ts ORDER BY _kafka_offset) AS rn
        FROM bronze.trip_event) WHERE rn = 1""",
"task": "SELECT task_id, trip_id, consignment_id, sequence FROM bronze.task",
"consignment": """
    SELECT c.consignment_id, c.trip_id,
           COALESCE(c.trip_id, k.trip_id)                              AS resolved_trip_id,
           CASE WHEN c.trip_id IS NOT NULL THEN 'consignment'
                WHEN k.trip_id IS NOT NULL THEN 'task' END             AS trip_id_source,
           c.sender_hub_id, c.destination_hub_id, c.customer_pincode, c.weight_kg, c.promised_date
    FROM bronze.consignment c LEFT JOIN bronze.task k USING (consignment_id)""",
"freight_bill": "SELECT tcn, trip_reference_number, estimated_freight, fuel_cost, toll_cost, actual_freight, bill_date FROM bronze.freight_bill",
}

GOLD = {
"gold_tat_trip_level": """
    WITH ev AS (
        SELECT trip_id,
               MIN(event_ts) FILTER (WHERE event_type = 'DELIVERED')  AS delivered_ts,
               COUNT(*)                                               AS event_count
        FROM silver.trip_event GROUP BY trip_id)
    SELECT t.trip_id, t.vendor_code_resolved AS vendor_code, t.origin_hub_id, t.business_unit,
           CAST(t.planned_start AS DATE)                    AS trip_date,
           CAST(date_trunc('week', t.planned_start) AS DATE) AS trip_week,
           t.planned_start, t.planned_end, t.actual_start, t.actual_end, ev.delivered_ts,
           CASE WHEN t.actual_start IS NOT NULL THEN 1 ELSE 0 END                         AS otdisp_den,
           CASE WHEN t.actual_start <= t.planned_start + INTERVAL 1 HOUR THEN 1 ELSE 0 END AS otdisp_num,
           CASE WHEN ev.delivered_ts IS NOT NULL THEN 1 ELSE 0 END                        AS otd_den,
           CASE WHEN ev.delivered_ts <= t.planned_end + INTERVAL 2 HOUR THEN 1 ELSE 0 END  AS otd_num,
           date_diff('minute', t.actual_start, ev.delivered_ts) / 60.0                    AS transit_hours
    FROM silver.trip t LEFT JOIN ev USING (trip_id)""",
"gold_detention_trip_level": """
    WITH g AS (
        SELECT trip_id,
               MIN(event_ts) FILTER (WHERE event_type = 'GATE_IN')  AS gate_in_ts,
               MIN(event_ts) FILTER (WHERE event_type = 'GATE_OUT') AS gate_out_ts
        FROM silver.trip_event GROUP BY trip_id)
    SELECT t.trip_id, t.vehicle_id, t.vendor_code_resolved AS vendor_code, t.origin_hub_id,
           CAST(t.planned_start AS DATE) AS trip_date,
           CAST(date_trunc('week', t.planned_start) AS DATE) AS trip_week,
           g.gate_in_ts, g.gate_out_ts,
           CASE WHEN g.gate_in_ts IS NOT NULL AND g.gate_out_ts IS NOT NULL THEN 1 ELSE 0 END AS has_gate_pair,
           GREATEST(date_diff('minute', g.gate_in_ts, g.gate_out_ts) / 60.0 - 2, 0)         AS detention_hours
    FROM silver.trip t LEFT JOIN g USING (trip_id)""",
"gold_utilization_trip_level": """
    SELECT t.trip_id, t.vehicle_id, t.vendor_code_resolved AS vendor_code, t.origin_hub_id,
           CAST(t.planned_start AS DATE) AS trip_date,
           CAST(date_trunc('week', t.planned_start) AS DATE) AS trip_week,
           v.vehicle_type, t.planned_load_kg, v.capacity_kg
    FROM silver.trip t LEFT JOIN silver.vehicle_master v USING (vehicle_id)""",
"gold_adoption_trip_level": """
    SELECT t.trip_id, t.vendor_code_resolved AS vendor_code, t.origin_hub_id,
           CAST(t.planned_start AS DATE) AS trip_date,
           CAST(date_trunc('week', t.planned_start) AS DATE) AS trip_week,
           COALESCE(e.n, 0) AS event_count,
           CASE WHEN COALESCE(e.n, 0) >= 2 THEN 1 ELSE 0 END AS is_tracked
    FROM silver.trip t
    LEFT JOIN (SELECT trip_id, COUNT(*) n FROM silver.trip_event GROUP BY trip_id) e USING (trip_id)""",
"gold_payment_trip_level": """
    SELECT t.trip_id, t.trip_reference_number, t.vendor_code_resolved AS vendor_code, t.origin_hub_id,
           CAST(t.planned_start AS DATE) AS trip_date,
           CAST(date_trunc('week', t.planned_start) AS DATE) AS trip_week,
           t.planned_load_kg, b.tcn, b.estimated_freight, b.actual_freight, b.fuel_cost, b.toll_cost,
           CASE WHEN b.tcn IS NOT NULL THEN 1 ELSE 0 END AS is_bill_matched,
           CASE WHEN t.actual_end IS NOT NULL THEN 1 ELSE 0 END AS is_completed
    FROM silver.trip t LEFT JOIN silver.freight_bill b USING (trip_reference_number)""",
}


def run(verbose: bool = True) -> None:
    con = duckdb.connect(str(WAREHOUSE))
    for layer, stmts in (("silver", SILVER), ("gold", GOLD)):
        for name, sql in stmts.items():
            con.execute(f"CREATE OR REPLACE TABLE {layer}.{name} AS {sql}")
            if verbose:
                n = con.execute(f"SELECT COUNT(*) FROM {layer}.{name}").fetchone()[0]
                print(f"  {layer}.{name:<30} {n:>8,} rows")
    con.close()


if __name__ == "__main__":
    run()
