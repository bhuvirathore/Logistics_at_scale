"""
Synthetic logistics (TMS) event generator  ->  BRONZE layer.

Mirrors the *shape* of an enterprise TMS fed by Kafka CDC (trips, trip events,
tasks, consignments, masters) plus an ERP freight-bill feed. No proprietary
schema, names or data are used. The data-quality defects found in the original
project are re-created as configurable "defect knobs", so the DQ engine and
agents have real problems to discover.
"""
from __future__ import annotations
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import duckdb
from .config import WAREHOUSE, DATA_DIR

DEFECTS = {
    "vendor_code_fill": 0.47,        # vendor code sparsely populated on trip
    "consignment_trip_fill": 0.14,   # consignment.trip_id rarely filled -> must route via task
    "gate_event_fill": 0.03,         # gate-in / gate-out events almost never emitted
    "orphan_sender_hub_rate": 0.04,  # sender hub that is missing from hub master
    "tcn_match_rate": 0.78,          # ERP freight bill <-> TMS trip reference match
    "duplicate_event_rate": 0.02,    # Kafka at-least-once delivery duplicates
    "bu_fill": 0.30,                 # business-unit dimension sparsely populated
    "null_est_freight_rate": 0.12,   # estimated freight missing on bills
    "untracked_trip_rate": 0.15,     # trips with no tracking events at all
}
# A story for the agent to find: one carrier degrades operationally AND its tracking
# feed breaks after DEGRADE_DAY, so the On-Time Delivery KPI drops and becomes less trustworthy.
DEGRADE_VENDOR, DEGRADE_DAY, TRACKING_BREAK_DAY = "V007", 62, 66

N_TRIPS, N_DAYS, START = 6000, 90, datetime(2026, 6, 1)
rng = np.random.default_rng(42)


def _masters():
    cities = ["Mumbai", "Pune", "Nagpur", "Ahmedabad", "Surat", "Indore", "Bhopal", "Jaipur",
              "Delhi", "Lucknow", "Kolkata", "Guwahati", "Bengaluru", "Chennai", "Hyderabad"]
    hubs = pd.DataFrame({
        "hub_id": [f"H{i:03d}" for i in range(1, 26)],
        "hub_name": [f"{cities[i % len(cities)]} {'Plant' if i < 6 else 'Depot'} {i}" for i in range(25)],
        "hub_type": ["PLANT" if i < 6 else "DEPOT" for i in range(25)],
        "city": [cities[i % len(cities)] for i in range(25)],
        "pincode": rng.integers(110001, 799999, 25).astype(str),
    })
    vendors = pd.DataFrame({
        "vendor_code": [f"V{i:03d}" for i in range(1, 16)],
        "vendor_name": [f"Carrier {chr(64 + i)} Logistics" for i in range(1, 16)],
        "vendor_type": rng.choice(["FTL", "PTL", "DEDICATED"], 15),
    })
    vtypes = {"TATA_ACE": 750, "EICHER_14FT": 4000, "TAURUS_22FT": 9000, "CONTAINER_32FT": 16000}
    vt = rng.choice(list(vtypes), 140)
    vehicles = pd.DataFrame({
        "vehicle_id": [f"VH{i:04d}" for i in range(1, 141)],
        "vehicle_type": vt,
        "capacity_kg": [vtypes[t] for t in vt],
        # V007 is a large carrier (~20% of the fleet) so its degradation moves the network KPI
        "vendor_code": rng.choice(vendors.vendor_code, 140, p=[0.2 if v == DEGRADE_VENDOR else 0.8 / 14 for v in vendors.vendor_code]),
    })
    return hubs, vendors, vehicles


def generate() -> dict[str, pd.DataFrame]:
    hubs, vendors, vehicles = _masters()
    plants = hubs[hubs.hub_type == "PLANT"].hub_id.values
    d = DEFECTS

    # ---------------- trips ----------------
    veh = vehicles.sample(N_TRIPS, replace=True, random_state=1).reset_index(drop=True)
    day = rng.integers(0, N_DAYS, N_TRIPS)
    planned_start = [START + timedelta(days=int(x), hours=int(h)) for x, h in zip(day, rng.integers(5, 20, N_TRIPS))]
    planned_hrs = rng.uniform(6, 48, N_TRIPS)
    start_delay = rng.normal(0.4, 1.5, N_TRIPS)
    transit_factor = rng.normal(1.0, 0.12, N_TRIPS)
    degraded = (veh.vendor_code.values == DEGRADE_VENDOR) & (day >= DEGRADE_DAY)
    transit_factor[degraded] += 0.22                       # operational degradation
    actual_start = [p + timedelta(hours=float(s)) for p, s in zip(planned_start, start_delay)]
    actual_end = [a + timedelta(hours=float(h * f)) for a, h, f in zip(actual_start, planned_hrs, transit_factor)]
    completed = rng.random(N_TRIPS) > 0.04
    trips = pd.DataFrame({
        "trip_id": [f"T{i:06d}" for i in range(N_TRIPS)],
        "trip_reference_number": [f"TRN{100000 + i}" for i in range(N_TRIPS)],
        "origin_hub_id": rng.choice(plants, N_TRIPS),
        "true_vendor_code": veh.vendor_code.values,         # kept only to drive generation
        "vehicle_id": veh.vehicle_id.values,
        "planned_start": planned_start,
        "planned_end": [p + timedelta(hours=float(h)) for p, h in zip(planned_start, planned_hrs)],
        "actual_start": actual_start,
        "actual_end": [e if c else None for e, c in zip(actual_end, completed)],
        "planned_load_kg": (veh.capacity_kg.values * rng.uniform(0.45, 1.0, N_TRIPS)).round(0),
        "business_unit": np.where(rng.random(N_TRIPS) < d["bu_fill"], rng.choice(["BEV", "FOODS", "HPC"], N_TRIPS), None),
    })
    trips["vendor_code"] = np.where(rng.random(N_TRIPS) < d["vendor_code_fill"], trips.true_vendor_code, None)

    # ---------------- trip events (Kafka) ----------------
    ev = []
    for t in trips.itertuples():
        tday = (t.planned_start - START).days
        if rng.random() < d["untracked_trip_rate"]:
            continue
        if t.true_vendor_code == DEGRADE_VENDOR and tday >= TRACKING_BREAK_DAY and rng.random() < 0.7:
            continue                                        # tracking feed breaks for one carrier
        if rng.random() < d["gate_event_fill"]:
            ev.append((t.trip_id, "GATE_IN", t.actual_start - timedelta(hours=float(rng.uniform(1, 6))), t.origin_hub_id))
            ev.append((t.trip_id, "GATE_OUT", t.actual_start - timedelta(minutes=10), t.origin_hub_id))
        ev.append((t.trip_id, "DISPATCHED", t.actual_start, t.origin_hub_id))
        for k in range(rng.integers(0, 4)):
            ev.append((t.trip_id, "IN_TRANSIT", t.actual_start + timedelta(hours=2 * (k + 1)), None))
        if pd.notna(t.actual_end) and rng.random() > 0.05:
            ev.append((t.trip_id, "DELIVERED", t.actual_end, None))
    events = pd.DataFrame(ev, columns=["trip_id", "event_type", "event_ts", "hub_id"])
    dups = events.sample(frac=d["duplicate_event_rate"], random_state=2)
    events = pd.concat([events, dups]).reset_index(drop=True)
    events.insert(0, "event_id", [f"E{i:08d}" for i in range(len(events))])
    events["_kafka_offset"] = np.arange(len(events))

    # ---------------- consignments + tasks ----------------
    n_cons = rng.integers(1, 4, N_TRIPS)
    cons_trip = np.repeat(trips.trip_id.values, n_cons)
    cons_origin = np.repeat(trips.origin_hub_id.values, n_cons)
    nc = len(cons_trip)
    sender = np.where(rng.random(nc) < d["orphan_sender_hub_rate"], "H900", cons_origin)  # H900 not in master
    tmap = trips.set_index("trip_id")
    consignments = pd.DataFrame({
        "consignment_id": [f"C{i:07d}" for i in range(nc)],
        "trip_id": np.where(rng.random(nc) < d["consignment_trip_fill"], cons_trip, None),
        "sender_hub_id": sender,
        "destination_hub_id": None,                       # always NULL in the source feed
        "customer_pincode": rng.integers(110001, 799999, nc).astype(str),
        "weight_kg": rng.uniform(50, 3000, nc).round(1),
        "promised_date": tmap.loc[cons_trip, "planned_end"].values,
    })
    tasks = pd.DataFrame({
        "task_id": [f"K{i:07d}" for i in range(nc)],
        "trip_id": np.where(rng.random(nc) < 0.985, cons_trip, None),
        "consignment_id": consignments.consignment_id.values,
        "sequence": np.concatenate([np.arange(1, k + 1) for k in n_cons]),
    })

    # ---------------- ERP freight bills (TCN) ----------------
    billed = trips[trips.actual_end.notna()].sample(frac=0.93, random_state=3)
    matched = rng.random(len(billed)) < d["tcn_match_rate"]
    base = (billed.planned_load_kg.values * rng.uniform(1.8, 2.6, len(billed))).round(0)
    bills = pd.DataFrame({
        "tcn": [f"TCN{9000000 + i}" for i in range(len(billed))],
        "trip_reference_number": np.where(matched, billed.trip_reference_number, [f"MANUAL-{x}" for x in rng.integers(1, 99999, len(billed))]),
        "estimated_freight": np.where(rng.random(len(billed)) < d["null_est_freight_rate"], None, base),
        "fuel_cost": (base * 0.55).round(0),
        "toll_cost": (base * 0.08).round(0),
        "actual_freight": (base * rng.uniform(0.95, 1.15, len(billed))).round(0),
        "bill_date": [e.date() + timedelta(days=int(x)) for e, x in zip(billed.actual_end, rng.integers(1, 15, len(billed)))],
    })

    trips = trips.drop(columns=["true_vendor_code"])
    return {"hub_master": hubs, "vendor_master": vendors, "vehicle_master": vehicles, "trip": trips,
            "trip_event": events, "task": tasks, "consignment": consignments, "freight_bill": bills}


def load_bronze(tables: dict[str, pd.DataFrame]) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    if WAREHOUSE.exists():
        WAREHOUSE.unlink()
    con = duckdb.connect(str(WAREHOUSE))
    for s in ("bronze", "silver", "gold", "ops"):
        con.execute(f"CREATE SCHEMA IF NOT EXISTS {s}")
    for name, df in tables.items():
        df = df.copy()
        df["_ingested_at"] = datetime.now()
        con.register("df", df)
        con.execute(f"CREATE TABLE bronze.{name} AS SELECT * FROM df")
        con.unregister("df")
    con.close()


if __name__ == "__main__":
    t = generate()
    load_bronze(t)
    print({k: len(v) for k, v in t.items()})
