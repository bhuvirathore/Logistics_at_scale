"""
Lineage graph derived purely from metadata:
  source system -> bronze -> silver -> gold -> KPI   (+ DQ checks guarding each KPI)
upstream(node)   : what feeds this?        e.g. KPI -> tables -> Kafka topic
downstream(node) : what breaks if this breaks?  e.g. silver.trip_event -> 3 KPIs
"""
from collections import defaultdict
from . import metadata as md


def _edges() -> list[tuple[str, str]]:
    m, e = md.load(), []
    for name, spec in m["entities"].items():
        src = "source:ERP freight bills" if name == "freight_bill" else f"source:TMS Kafka CDC ({name})"
        e += [(src, spec["source"]), (spec["source"], spec["table"])]
    e.append(("bronze.task", "silver.consignment"))          # task-table trip resolution
    e.append(("bronze.vehicle_master", "silver.trip"))       # vendor resolution
    for g, spec in m["gold_tables"].items():
        e += [(s, f"gold.{g}") for s in spec["sources"]]
    for k, spec in m["kpis"].items():
        e.append((f"gold.{spec['gold_table']}", f"kpi:{k}"))
        e += [(f"dq:{c}", f"kpi:{k}") for c in spec.get("dq_dependencies", [])]
    return e


def _graph(reverse=False):
    g = defaultdict(set)
    for a, b in _edges():
        (g[b] if reverse else g[a]).add(a if reverse else b)
    return g


def _normalise(node: str) -> str:
    if ":" in node or "." in node:
        return node
    if node in md.load()["kpis"]:
        return f"kpi:{node}"
    if node in md.load()["gold_tables"]:
        return f"gold.{node}"
    return f"silver.{node}"


def _walk(node: str, g) -> dict:
    seen, tree = set(), {}

    def rec(n):
        if n in seen:
            return {}
        seen.add(n)
        return {c: rec(c) for c in sorted(g.get(n, []))}
    tree[node] = rec(node)
    return tree


def upstream(node: str) -> dict:
    return _walk(_normalise(node), _graph(reverse=True))


def downstream(node: str) -> dict:
    return _walk(_normalise(node), _graph())


def affected_kpis(node: str) -> list[str]:
    out, stack, g = set(), [_normalise(node)], _graph()
    while stack:
        n = stack.pop()
        for c in g.get(n, []):
            if c.startswith("kpi:"):
                out.add(c[4:])
            stack.append(c)
    return sorted(out)


def render(tree: dict) -> str:
    def kids(children: dict, prefix: str) -> list[str]:
        out, items = [], list(children.items())
        for i, (k, v) in enumerate(items):
            last = i == len(items) - 1
            out.append(prefix + ("└── " if last else "├── ") + k)
            out += kids(v, prefix + ("    " if last else "│   "))
        return out
    lines = []
    for root, children in tree.items():
        lines += [root] + kids(children, "")
    return "\n".join(lines)
