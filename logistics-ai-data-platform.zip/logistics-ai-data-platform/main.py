"""
Logistics Data Quality & AI Intelligence Platform — CLI

  python main.py build                 generate synthetic data -> Bronze -> Silver -> Gold -> DQ run
  python main.py dq                    DQ scorecard + failing checks
  python main.py kpis                  every KPI with its reliability status
  python main.py ask "question"        ask the agent (LLM mode if ANTHROPIC_API_KEY is set)
  python main.py chat                  interactive agent session
  python main.py demo                  scripted walkthrough for interviews
"""
import argparse
import pandas as pd
from platform_core import generator, pipeline
from platform_core.dq_engine import DQEngine
from platform_core.kpi_engine import KPIEngine
from platform_core import metadata as md

pd.set_option("display.width", 160, "display.max_columns", 20)


def build():
    print("1/3  Generating synthetic TMS + ERP data -> bronze")
    generator.load_bronze(generator.generate())
    print("2/3  Bronze -> Silver -> Gold")
    pipeline.run()
    print("3/3  Running data-quality checks -> ops.dq_results")
    dq()


def dq():
    eng = DQEngine()
    df = eng.run_all()
    print("\nDQ score by entity (0-100):\n", DQEngine.scores(df).to_string())
    bad = df[df.status != "PASS"].sort_values("pass_rate")
    print(f"\n{len(bad)} checks below threshold:")
    print(bad[["check_id", "dimension", "pass_rate", "threshold", "status"]].to_string(index=False))


def kpis():
    k = KPIEngine()
    rows = []
    for name in md.load()["kpis"]:
        v = k.calculate(name).iloc[0][name]
        rel = k.assess_impact(name)
        rows.append({"kpi": name, "module": md.kpi(name)["module"], "value": v,
                     "reliability": rel["reliability"], "weakest_dependency": f"{rel['weakest_pass_rate']:.1%}"})
    print(pd.DataFrame(rows).to_string(index=False))


def ask(q: str, show_trace: bool = True):
    from agents.data_agent import LogisticsDataAgent
    r = LogisticsDataAgent().ask(q)
    print(f"\nQ: {q}\n[intent: {r.intent}]\n\n{r.answer}")
    if show_trace:
        print("\nTool trace: " + " -> ".join(t["tool"] for t in r.trace))


def demo():
    for q in ["What tables contribute to the On-Time Delivery KPI?",
              "Why did on-time delivery decline last month?",
              "Can I trust the detention numbers?",
              "Is the TCN match rate good enough for cost dashboards?"]:
        ask(q)
        print("\n" + "=" * 100)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("cmd", choices=["build", "dq", "kpis", "ask", "chat", "demo"])
    p.add_argument("question", nargs="?")
    a = p.parse_args()
    if a.cmd == "ask":
        ask(a.question or "Why did on-time delivery decline?")
    elif a.cmd == "chat":
        while (q := input("\nask> ").strip()) not in ("", "exit", "quit"):
            ask(q)
    else:
        {"build": build, "dq": dq, "kpis": kpis, "demo": demo}[a.cmd]()
