"""
MCP server exposing the platform's deterministic capabilities as tools.

Run:   python -m mcp_server.server        (stdio transport)
Then register it in any MCP client (Claude Desktop, Claude Code, an IDE agent):
  {"mcpServers": {"logistics-data-platform": {"command": "python", "args": ["-m", "mcp_server.server"],
                                              "cwd": "/path/to/logistics-ai-data-platform"}}}
The client's LLM does the reasoning; this server only executes.
"""
try:                                   # mcp >= 2.x
    from mcp.server.mcpserver import MCPServer as Server
except ImportError:                    # mcp 1.x
    from mcp.server.fastmcp import FastMCP as Server
from agents import tools as T

mcp = Server("logistics-data-platform")

for fn in T.TOOLS.values():          # one registration per tool; docstrings become tool descriptions
    mcp.tool()(fn)

if __name__ == "__main__":
    mcp.run()
